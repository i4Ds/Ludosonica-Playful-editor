/**
 * Created by flo on 7/23/15.
 */
var Tools = function (editor) {
};