Sidebars.SoundProperties = function (editor) {

    var container = new UI.Panel();

    $("<h2/>").html("Sound Properties").appendTo(container.dom);
    container.add(new UI.SoundProperties());
    return container;
}
