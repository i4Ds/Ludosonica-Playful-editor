Sidebars.Properties = function ( editor ) {

	var signals = editor.signals;

	var container = new UI.Panel();

	$("<h2/>").html("Properties").appendTo(container.dom);
	var properties = new UI.Panel();

	properties.add( new Sidebars.Properties.Scene( editor ) );

	try {
		if (editor instanceof Editor.Leap) properties.add(new Sidebars.Properties.LeapEvents(editor));
	} catch (e) {
	}

	try {
		if (editor instanceof Editor.Kinect) properties.add(new Sidebars.Properties.KinectEvents(editor));
	} catch (e) {
	}

	properties.add( new Sidebars.Properties.Object3D( editor ) );
	properties.add( new Sidebars.Properties.Geometry( editor ) );
	properties.add( new Sidebars.Properties.Physics( editor ) );
	properties.add( new Sidebars.Properties.Material( editor ) );
	properties.add( new Sidebars.Properties.Animation( editor ) );
	properties.add( new Sidebars.Properties.Behaviors( editor ) );
	
	properties.add( new Sidebars.Properties.AdvancedSwitch( editor, container ) );

	container.add(properties);
	return container;
}
