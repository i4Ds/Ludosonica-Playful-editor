
/**
 * Created by flo on 5/5/15.
 */
Play.Kinect = function (editor) {

    this.personMap = {};

    this.characterColorMap = {
        Orange  : {hex:0xFF9900, used:false},
        Lime    : {hex:0x00FF00, used:false},
        Blue    : {hex:0x33CCFF, used:false},
        Yellow  : {hex:0xFFFF00, used:false},
        White   : {hex:0xFFFFFF, used:false},
        Black   : {hex:0x000000, used:false}
    };

    this._gestureTable = new UI.VisualFeedback();

};

Play.Kinect.prototype.playAction = function (object, eventIndex, progress) {

    var action = object.events[eventIndex].action;

    switch (action.type) {

        case 'Play sound':
            console.log("playAction: Play sound");
            editor.soundCollection.playAttachedSound(action.sound, object, false, true);
            break;

        case 'Stop sound':
            console.log('playAction: Stop sound');
            editor.soundCollection.stopAll(object);
            break;

        case 'Play loop':
            console.log('playAction: Play loop');
            editor.soundCollection.playAttachedSound(action.sound, object, true, true);
            break;

        case 'Stop loop':
            console.log('playAction: Stop loop');
            editor.soundCollection.stopAll(object);
            break;

        case 'Loop delay':
            console.log("playAction: Loop delay");
            editor.soundCollection.changeDelay(object, progress);
            break;

        case 'Volume':
            console.log("playAction: Volume");
            editor.soundCollection.changeVolume(object, progress);
            break;

        case 'Speed':
            console.log("playAction: Speed");
            editor.soundCollection.changePlaybackRate(object, progress);
            break;

        case 'Lowpass':
            console.log("playAction: Lowpass");
            editor.soundCollection.changeLowpass(object, progress);
            break;

        case 'Highpass':
            console.log("playAction: Highpass");
            editor.soundCollection.changeHighpass(object, progress);
            break;

        case 'Bandpass':
            console.log("playAction: Bandpass");
            editor.soundCollection.changeBandpass(object, progress);
            break;

        case 'Lowshelf':
            console.log("playAction: Lowshelf");
            editor.soundCollection.changeLowshelf(object, progress);
            break;

        case 'Highshelf':
            console.log("playAction: Highshelf");
            editor.soundCollection.changeHighshelf(object, progress);
            break;

        case 'Peaking':
            console.log("playAction: Peaking");
            editor.soundCollection.changePeaking(object, progress);
            break;

        case 'Notch':
            console.log("playAction: Notch");
            editor.soundCollection.changeNotch(object, progress);
            break;

        case 'Allpass':
            console.log("playAction: Allpass");
            editor.soundCollection.changeAllpass(object, progress);
            break;

        case 'Reverb':
            console.log("playAction: Reverb");
            editor.soundCollection.setReverb(object, false);
            break;

        case 'Tremolo':
            console.log("playAction: Tremolo");
            editor.soundCollection.setTremolo(object, false);
            break;

        case 'WahWah':
            console.log("playAction: WahWah");
            editor.soundCollection.setWahWah(object, false);
            break;

        case 'Reset filters':
            console.log('playAction: Reset Filters');
            editor.soundCollection.resetFilters(object);
            break;
    }
};

Play.Kinect.prototype.setContainer = function (container) {
    this._container = container;
    this._container.add(this._gestureTable);
};

Play.Kinect.prototype.setupVisualFeedback = function (character) {
    this._gestureTable.setCharacter('none', character._color);
};

Play.Kinect.prototype.updateVisualFeedback = function (character, gesture) {
    this._gestureTable.updateCharacter(character._color, gesture);
};

Play.Kinect.prototype.start = function () {
    //Set target position of rotation to middle of the KinectBox
    editor._activeControls.target.x = 0;
    editor._activeControls.target.z = 2.25;
    editor._activeControls.target.y = 0;
};

Play.Kinect.prototype.createPlayerCharacter = function (x, y, z) {

    //create floating bright ball
    var radius = 0.07;
    var widthSegments = 16;
    var heightSegments = 16;
    var color;

    //get the next unused color from the map for the color of the ball
    for (var key in this.characterColorMap) {
        var val = this.characterColorMap[key];
        if (!val.used) {
            color = val.hex;
            this.characterColorMap[key].used = true;
            break;
        }
    }

    var geometry = new THREE.SphereGeometry(radius, widthSegments, heightSegments);
    var material = Physijs.createMaterial(
        new THREE.MeshBasicMaterial(),
        0.5,
        0.5
    );
    material.color.set(color);
    var mesh = new Physijs.SphereMesh(geometry, material, 0.01);

    mesh.name = 'PlayerCharacter';

    var light = new THREE.PointLight(color, 2, 4);
    mesh.add(light);

    mesh.castShadow = true;
    mesh.position.set(x, y, z);
    mesh._physijs.collision_flags = 4;

    var character = mesh;
    character._color = color;

    editor.scene.add(character);

    // we don't want it to turn and jump around
    mesh.setLinearFactor(new THREE.Vector3(0, 0, 0));
    mesh.setAngularFactor(new THREE.Vector3(0, 0, 0));
    mesh.setLinearVelocity(new THREE.Vector3(0, 0, 0));
    mesh.setAngularVelocity(new THREE.Vector3(0, 0, 0));

    return character;

};

Play.Kinect.prototype.removePlayerCharacter = function (character) {

    //release the attached color in the map
    color = character._color;
    for (var key in this.characterColorMap) {
        var val = this.characterColorMap[key];
        if (val.hex == color) {
            this.characterColorMap[key].used = false;
            break;
        }
    }

    this._gestureTable.removeCharacter(character._color);

    character.parent.remove(character);
    character.material.dispose();
    character.geometry.dispose();
    character = undefined;

};

Play.Kinect.prototype.preloadSounds = function (object) {
    for (var k in object) {
        if (object.hasOwnProperty(k)) {
            if (k == 'sound' && object[k] != undefined) {
                if (editor.soundCollection._getSoundIndex(object[k]) == -1) editor.soundCollection.add(object[k]);
            } else if (typeof object[k] == 'object') {
                editor.play.preloadSounds(object[k]);
            }
        }
    }
};

Play.Kinect.prototype.stop = function () {
    for (var trackingId in this.personMap) {
        this.removePlayerCharacter(this.personMap[trackingId].character);
        delete this.personMap[trackingId];
    }
};

Play.Kinect.prototype._playLoop = function () {
    for (var trackingId in this.personMap) {
        var character = this.personMap[trackingId].character;
        character.__dirtyPosition = true;
        var touches = character._physijs.touches;

        //let the character glow
        var scale = touches.length > 0 ? 1.5 : 1;
        character.scale.set(scale, scale, scale);
    }
};

Play.Kinect.prototype.eventToTouchedObjects = function (character, gesture, progress) {

    var touches = character._physijs.touches;

    // loop through all touched objects and assign touch events
    var obj;
    for (var x = 0; x < touches.length; x++) {
        obj = editor.scene._objects[touches[x]];
        if (obj[gesture] !== undefined) {
            obj[gesture](progress);
            this.updateVisualFeedback(character, gesture);
        }
    }
};

Play.Kinect.prototype.setupSocket = function () {
    var connection = this;
    var socket = new WebSocket(this.getUrl());
    socket.onopen = function () {
        connection.handleOpen();
    };
    socket.onclose = function (data) {
        connection.handleClose(data['code'], data['reason']);
    };
    socket.onmessage = function (message) {
        connection.handleData(message.data)
    };
    socket.onerror = function (error) {
        connection.handleError(error.data)
    };
    return socket;
};

Play.Kinect.prototype.getUrl = function () {
    return "ws://localhost:6789";
};

Play.Kinect.prototype.handleOpen = function () {
    editor.signals.connect.dispatch();
    console.log("WebSocket to SonciClassroom Client open");
};

Play.Kinect.prototype.handleClose = function (code) {
    if (this.socket.readyState !== 3) this.socket.close();
    // Websocket CloseEvent: 1000 = CLOSE_NORMAL, 1006 = CLOSE_ABNORMAL, 1005 = CLOSE_NO_STATUS
    // https://tools.ietf.org/html/rfc6455, chapter 7.4.1 Defined Status Codes
    if (code !== 1000 && code !== 1005) window.alert("Keine Verbindung zur Kinect!");
    this.socket = null;
    editor.signals.disconnect.dispatch();
};

Play.Kinect.prototype.handleData = function (data) {

    var dataset = JSON.parse(data);

    var trackingId = dataset.trackingId;
    var x = dataset.x;
    var y = dataset.y;
    var z = dataset.z;
    var gesture = dataset.gesture;
    var progress = dataset.progress;

    if (trackingId in this.personMap) {
        if (gesture == "tracking_lost") {
            this.removePlayerCharacter(this.personMap[trackingId].character);
            delete this.personMap[trackingId];
        } else {
            var person = this.personMap[trackingId];
            person.character.position.set(x, y, z);
            person.currentGesture = gesture;
            person.currentGestureProgress = progress;
            if (progress != "discrete") {
                this.eventToTouchedObjects(person.character, person.currentGesture, person.currentGestureProgress);
            } else if (gesture != person.lastGesture) {
                person.lastGesture = gesture;
                if (gesture != "none") {
                    this.eventToTouchedObjects(person.character, person.currentGesture, person.currentGestureProgress);
                }
            }
        }
    } else if (gesture != "tracking_lost") {
        var character = this.createPlayerCharacter(x, y, z);
        var person = {
            currentGesture: gesture,
            currentGestureProgress: progress,
            lastGesture: gesture,
            character: character
        };
        this.personMap[trackingId] = person;
        this.setupVisualFeedback(character);
        this.eventToTouchedObjects(person.character, person.currentGesture, person.currentGestureProgress);
    }
};

Play.Kinect.prototype.handleError = function () {
    editor.signals.disconnect.dispatch();
};

Play.Kinect.prototype.connect = function () {
    this.socket = this.setupSocket();
};

Play.Kinect.prototype.disconnect = function () {
    if (this.socket) {
        this.socket.close();
    }
};