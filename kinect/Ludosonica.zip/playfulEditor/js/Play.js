var Play = function (editor) {
};