var Viewport = function (editor) {
};