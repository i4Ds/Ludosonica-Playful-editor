var Editor = function () {
};