Tools.Kinect.Modes = function (editor) {

    var buttonpanel = new UI.ButtonHelper.createButtonPanel("modes", true);
    var signals = editor.signals;

    var playing = false;
    var connecting = false;


    signals.connect.add(function () {
        if (!playing) {
            viewport.maximize();
            editor.signals.play.dispatch();
            playing = true;
            connecting = false;
        }
    });
    signals.disconnect.add(function () {
        if (playing) {
            viewport.windowed();
            editor.signals.stop.dispatch();
            playing = false;
        }
        connecting = false;
        $("#modes").find(".active").removeClass("active");
    });

    buttonpanel.addButton("icon-translate active", function () {
        if(playing) {
            editor.play.disconnect();
        }
        signals.transformModeChanged.dispatch('translate');
    });
    buttonpanel.addButton("icon-scale", function () {
        if(playing) {
            editor.play.disconnect();
        }
        signals.transformModeChanged.dispatch('scale');
    });
    buttonpanel.addButton("icon-rotate", function () {
        if(playing) {
            editor.play.disconnect();
        }
        signals.transformModeChanged.dispatch('rotate');
    });
    buttonpanel.addButton("icon-play", function () {
        if (playing) {
            editor.play.disconnect();
        } else if(!connecting){
                connecting = true;
                editor.play.connect();
        }
    });

    return buttonpanel;

};
