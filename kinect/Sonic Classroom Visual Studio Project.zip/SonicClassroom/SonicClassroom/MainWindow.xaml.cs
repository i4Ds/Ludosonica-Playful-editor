﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Kinect;
using SonicClassroom.Gestures;
using SonicClassroom.Server;

namespace SonicClassroom
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private KinectSensor _kinectSensor;
        private BodyFrameReader _bodyFrameReader;
        private Body[] _bodies = null;
        private List<GestureDetector> _gestureDetectorList;
        private readonly KinectWebSocketServer _kinectWebSocketServer;
        private string _kinectStatusText;
        private SolidColorBrush _kinectStatusColor;
        private static readonly  SolidColorBrush ConnectedColor = new SolidColorBrush(Colors.LawnGreen);
        private static readonly SolidColorBrush DisconnectedColor = new SolidColorBrush(Colors.Red);

        /// <summary>
        /// Opens kinect sensor and body frame reader.
        /// </summary>
        public MainWindow()
        {
            //Change separator from comma to dot
            System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;

            _kinectSensor = KinectSensor.GetDefault();
            _kinectSensor.IsAvailableChanged += Sensor_IsAvailableChanged;
            _kinectSensor.Open();

            _bodyFrameReader = _kinectSensor.BodyFrameSource.OpenReader();

            _gestureDetectorList = new List<GestureDetector>();
            _kinectWebSocketServer = new KinectWebSocketServer();

            InitializeComponent();
            DataContext = this;
        }

        /// <summary>
        /// Gets called, when the window is loaded. 
        /// Starts the WebSocket Server and registers the frame reader and gesture detectors.
        /// </summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">event arguments</param>
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _kinectWebSocketServer.StartServer();
            if (_bodyFrameReader != null)
            {
                _bodyFrameReader.FrameArrived += this.Reader_FrameArrived;
            }

            int maxBodies = _kinectSensor.BodyFrameSource.BodyCount;

            for (int i = 0; i < maxBodies; i++)
            {
                _gestureDetectorList.Add(new GestureDetector(_kinectSensor, _kinectWebSocketServer));
            }
        }

        /// <summary>
        /// Contains text with sensor status for the GUI.
        /// </summary>
        public string KinectStatusText
        {
            get { return _kinectStatusText; }
            set
            {
                if (_kinectStatusText != value)
                {
                    _kinectStatusText = value;

                    NotifyPropertyChanged("KinectStatusText");
                }
            }
        }

        /// <summary>
        /// Contains color (green, red) of the sensor status for the GUI.
        /// </summary>
        public SolidColorBrush KinectStatusColor
        {

            get { return _kinectStatusColor; }
            set
            {
                if (!Equals(_kinectStatusColor, value))
                {
                    _kinectStatusColor = value;

                    NotifyPropertyChanged("KinectStatusColor");
                }

            }
        }

        /// <summary>
        /// Gets called on sensor availability changes.
        /// </summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">event arguments</param>
        private void Sensor_IsAvailableChanged(object sender, IsAvailableChangedEventArgs e)
        {
            Debug.WriteLine("Sensor available: " + e.IsAvailable);
            KinectStatusText = e.IsAvailable
                ? Properties.Resources.KinectConnected
                : Properties.Resources.KinectDisconnected;

            KinectStatusColor = e.IsAvailable ? ConnectedColor : DisconnectedColor;
        }

        /// <summary>
        /// Gets called when a body frame arrives.
        /// Updates the height of the kinect.
        /// Updates the trackingId and the body of every gesture detectors.
        /// </summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">event arguments</param>
        private void Reader_FrameArrived(object sender, BodyFrameArrivedEventArgs e)
        {
            bool dataReceived = false;
            using (BodyFrame bodyFrame = e.FrameReference.AcquireFrame())
            {
                if (bodyFrame != null)
                {
                    //get height of kinect with the floor clip plane
                    JSONParser.KinectHeight = bodyFrame.FloorClipPlane.W;
                    
                    if (_bodies == null)
                    {
                        _bodies = new Body[bodyFrame.BodyCount];
                    }

                    //refresh body data on the existing body array
                    bodyFrame.GetAndRefreshBodyData(_bodies);
                    dataReceived = true;
                }
            }

            if (dataReceived)
            {

                if (_bodies != null)
                {
                    int maxBodies = _kinectSensor.BodyFrameSource.BodyCount;
                    for (int i = 0; i < maxBodies; ++i)
                    {
                        Body body = _bodies[i];
                   
                        ulong trackingId = body.TrackingId;
                        _gestureDetectorList[i].Body = body;

                        // update the gesture detectors tracking Id if it has changed
                        if (trackingId != _gestureDetectorList[i].TrackingId)
                        {
                            _gestureDetectorList[i].TrackingId = trackingId;

                            //pause the detector if the current body is not tracked.
                            //unpause the detector if the current body is tracked.
                            _gestureDetectorList[i].IsPaused = trackingId == 0;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Notifies the user interface about changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        
        /// <summary>
        /// Triggers a PropertyChanged event.
        /// </summary>
        /// <param name="propertyName">name of the changed property</param>
        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        /// <summary>
        /// Starts Ludosonica in an external browser. 
        /// </summary>
        /// <param name="sender">button sending the event</param>
        /// <param name="e">event arguments</param>
        private void OnStartLudosonicaClick(object sender, RoutedEventArgs e)
        {
            Process.Start(Properties.Resources.LudosonicaPath);
        }

        /// <summary>
        /// Gets called before the application closes. 
        /// Stops the server and disposes the frame reader, the sensor and all gesture detectors. 
        /// </summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">event arguments</param>
        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            if (_bodyFrameReader != null)
            {
                _bodyFrameReader.FrameArrived -= Reader_FrameArrived;
                _bodyFrameReader.Dispose();
                _bodyFrameReader = null;
            }

            if (_gestureDetectorList != null)
            {
                foreach (GestureDetector detector in _gestureDetectorList)
                {
                    detector.Dispose();
                }
                _gestureDetectorList.Clear();
                _gestureDetectorList = null;
            }

            if (_kinectSensor != null)
            {
                _kinectSensor.IsAvailableChanged -= Sensor_IsAvailableChanged;
                _kinectSensor.Close();
                _kinectSensor = null;
            }

            _kinectWebSocketServer.StopServer();
        }
    }
}
