﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.Kinect;
using Microsoft.Kinect.VisualGestureBuilder;
using SonicClassroom.Server;

namespace SonicClassroom.Gestures
{
    class GestureDetector : IDisposable
    {
        private readonly KinectSensor _kinectSensor;
        private VisualGestureBuilderFrameSource _vgbFrameSource = null;
        private VisualGestureBuilderFrameReader _vgbFrameReader = null;
        private readonly KinectWebSocketServer _kinectWebSocketServer;
        private ulong _formerTrackingId;
        private const String LeftArm = "left_arm";
        private const String RightArm = "right_arm";
        private const float MinConfidence = 0.2f;
        private const float MinProgess = 0.1f;
        private const float MinAveragetrackingState = 1.65f;


        private const String GestureDatabase = @"Gestures\SonicClassroomGestures.gbd";

        /// <summary>
        /// Initializes the Gesture Detector.
        /// Registers trackingId lost and gesture frame arrived methods and attaches the gesture database to the frame source
        /// </summary>
        /// <param name="kinectSensor">kinect sensor</param>
        /// <param name="kinectWebSocketServer">WebSocket server</param>
        public GestureDetector(KinectSensor kinectSensor, KinectWebSocketServer kinectWebSocketServer)
        {
            if (kinectSensor == null)
            {
                throw new ArgumentNullException("kinectSensor");
            }

            if (kinectWebSocketServer == null)
            {
                throw new ArgumentNullException("kinectWebSocketServer");
            }

            _kinectSensor = kinectSensor;
            _kinectWebSocketServer = kinectWebSocketServer;

            _vgbFrameSource = new VisualGestureBuilderFrameSource(_kinectSensor, 0);
            _vgbFrameSource.TrackingIdLost += Source_TrackingIdLost;


            _vgbFrameReader = this._vgbFrameSource.OpenReader();
            if (_vgbFrameReader != null)
           {
                _vgbFrameReader.IsPaused = true;
                _vgbFrameReader.FrameArrived += this.Reader_GestureFrameArrived;
           }

            using (VisualGestureBuilderDatabase database = new VisualGestureBuilderDatabase(GestureDatabase))
            {
                _vgbFrameSource.AddGestures(database.AvailableGestures);
            }
    
        }

        /// <summary>
        /// Gets called when a body is not tracked anymore.
        /// Sends a broadcast to all clients with a tracking lost message including the former trackingId.
        /// </summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">event arguments</param>
        private void Source_TrackingIdLost(object sender, TrackingIdLostEventArgs e)
        {
            
            Debug.WriteLine("Lost ID:" + _formerTrackingId);
            _kinectWebSocketServer.Broadcast(JSONParser.ParseTrackingLost(_formerTrackingId));

        }

        /// <summary>
        /// Contains the trackingId of the body attached to the gesture detector.
        /// </summary>
        public ulong TrackingId
        {
            get
            {
                return _vgbFrameSource.TrackingId;
            }

            set
            {
                Debug.WriteLine("New Tracking ID: " + value);
                if (_vgbFrameSource.TrackingId != value)
                {
                    if (value == 0)
                    {
                        _formerTrackingId = TrackingId;
                    }
                    _vgbFrameSource.TrackingId = value;
                }
            }
        }

        /// <summary>
        /// Contains the body of this gesture detector. 
        /// </summary>
        public Body Body { get; set; }
    
        /// <summary>
        /// Contains the running status of the gesture detector.
        /// </summary>
        public bool IsPaused
        {
            get
            {
                return _vgbFrameReader.IsPaused;
            }

            set
            {
                if (_vgbFrameReader.IsPaused != value)
                {
                    _vgbFrameReader.IsPaused = value;
                }
            }
        }


        /// <summary>
        /// Gets called when a GestureFrame arrives.
        /// Sends a broadcasts to the clients for all detected gestures.
        /// </summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">event arguments</param>
        private void Reader_GestureFrameArrived(object sender, VisualGestureBuilderFrameArrivedEventArgs e)
        {
            bool discreteGestureFound = false;
            using (VisualGestureBuilderFrame frame = e.FrameReference.AcquireFrame())
            {
                var joints = Body.Joints;

                //check if the skeleton is detected correctly 
                if (frame != null && IsBodyDetectedCorrectly(joints))
                {
                    var spinebase = joints[JointType.SpineBase];

                    IReadOnlyDictionary<Gesture, DiscreteGestureResult> discreteResults = frame.DiscreteGestureResults;
                    IReadOnlyDictionary<Gesture, ContinuousGestureResult> continousResults = frame.ContinuousGestureResults;


                    if (spinebase.TrackingState == TrackingState.Tracked && discreteResults != null && continousResults != null)
                    {
                        //position of the body
                        var position = spinebase.Position;

                        foreach (Gesture gesture in _vgbFrameSource.Gestures)
                        {
                            if (gesture.GestureType == GestureType.Discrete)
                            {
                                DiscreteGestureResult result = null;
                                discreteResults.TryGetValue(gesture, out result);

                                //only send a broadcast if gesture is detected 
                                if (result.Detected && result.Confidence >= MinConfidence)
                                {
                                    discreteGestureFound = true;
                                    _kinectWebSocketServer.Broadcast(JSONParser.ParseDiscreteGesture(TrackingId, position.X, position.Y, position.Z, gesture.Name));
                                }
                            }
                            else if (gesture.GestureType == GestureType.Continuous)
                            {
                                ContinuousGestureResult result = null;
                                continousResults.TryGetValue(gesture, out result);
                                bool leftHandClosed = Body.HandLeftState.Equals(HandState.Closed);
                                bool rightHandClosed = Body.HandRightState.Equals(HandState.Closed);
                                bool leftArm = gesture.Name.Contains(LeftArm);
                                bool rightArm = gesture.Name.Contains(RightArm);

                                //Only sendbBroadcast when progress is more than 10 % 
                                // and left arm with a fist
                                // or right arm with a fist
                                // or neither left nor right arm but at least one fist
                               if (result.Progress > MinProgess && (
                                    (leftArm && leftHandClosed) ||
                                    (rightArm && rightHandClosed) ||
                                    ((leftHandClosed || rightHandClosed) && !leftArm && !rightArm)))
                                {
                                    _kinectWebSocketServer.Broadcast(JSONParser.ParseContinuousGesture(TrackingId, position.X, position.Y, position.Z, gesture.Name, result.Progress));
                                }
                            }
                        }

                        //if no discrete gesture is detected, send a broadcast with the position.
                        //required to determine if a gesture is detected multiple times (in the web application)
                        //example: clap_front gets detected twice if at least one segment between the claps has been an other gesture or a position gesture.
                        if (!discreteGestureFound)
                        {
                            _kinectWebSocketServer.Broadcast(JSONParser.ParseWithoutGesture(TrackingId, position.X, position.Y, position.Z));
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Checks if the body is detection is reliable.
        /// </summary>
        /// <param name="joints">joints of the body</param>
        /// <returns>reliable or not</returns>
        private bool IsBodyDetectedCorrectly(IReadOnlyDictionary<JointType,Joint> joints)
        {
            var jointCount = joints.Count;
            
            var trackingStateCount = joints.Sum(joint => (float) joint.Value.TrackingState);
            var averageTrackingState = trackingStateCount/jointCount;

            return averageTrackingState > MinAveragetrackingState;
        }

        /// <summary>
        /// Disposes the frame reader and the frame source.
        /// </summary>
        public void Dispose()
        {
            {
                if (_vgbFrameReader != null)
                {
                    _vgbFrameReader.FrameArrived -= this.Reader_GestureFrameArrived;
                    _vgbFrameReader.Dispose();
                    _vgbFrameReader = null;
                }

                if (_vgbFrameSource != null)
                {
                    _vgbFrameSource.TrackingIdLost -= this.Source_TrackingIdLost;
                    _vgbFrameSource.Dispose();
                    _vgbFrameSource = null;
                }
            }
        }
    }
}
