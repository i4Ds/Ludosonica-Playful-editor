﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using Alchemy;
using Alchemy.Classes;

namespace SonicClassroom.Server
{
    class KinectWebSocketServer
    {

        private readonly WebSocketServer _webSocketServer;
        private readonly ConcurrentDictionary<EndPoint,UserContext> _connections; 
        
        /// <summary>
        /// Initializes the WebSocket server on Port 6789.
        /// </summary>
        public KinectWebSocketServer()
        {
            _webSocketServer = new WebSocketServer(false,6789, IPAddress.Any)
            {
                OnReceive = OnReceive,
                OnSend = OnSend,
                OnConnect = OnConnect,
                OnConnected = OnConnected,
                OnDisconnect = OnDisconnect,
                TimeOut = new TimeSpan(0,5,0)
            };

            _connections = new ConcurrentDictionary<EndPoint, UserContext>();
            Debug.WriteLine("Websocket Server created");
        }

        /// <summary>
        /// Starts the WebSocket server.
        /// </summary>
        public void StartServer()
        {
            _webSocketServer.Start();
            Debug.WriteLine("Websocket Server started on Port " + _webSocketServer.Port);
            
        }

        /// <summary>
        /// Disconnects all clients and stops the WebSocketServer.
        /// Clears the client list.
        /// </summary>
        public void StopServer()
        {
            foreach (var connection in _connections)
            {
                connection.Value.Disconnect();
            }

            _connections.Clear();

            
            _webSocketServer.Stop();
            Debug.WriteLine("Server stopped");           
        }

        /// <summary>
        /// Sends message to all connected clients.
        /// </summary>
        /// <param name="data">message</param>
        public void Broadcast(String data)
        {
            foreach (var connection in _connections)
            {
                connection.Value.Send(data);
            }
            
        }

        /// <summary>
        /// Gets called at beginning of the connection handshake.
        /// </summary>
        /// <param name="context">user's connection context</param>
        private void OnConnect(UserContext context){}

        /// <summary>
        /// Gets called when a connection is established.
        /// Saves the connection to the client list.
        /// </summary>
        /// <param name="context">user's connection context</param>
        private void OnConnected(UserContext context)
        {
            _connections.TryAdd(context.ClientAddress, context);
            Debug.WriteLine("Connected to Client: " + context.ClientAddress);
        }

        /// <summary>
        /// Gets called when the connection closes.
        /// Removes client from client list.
        /// </summary>
        /// <param name="context">user's connection context</param>
        private void OnDisconnect(UserContext context)
        {
            var clientAddress = context.ClientAddress;
            _connections.TryRemove(clientAddress, out context);
            Debug.WriteLine("Disconnect Client: " + clientAddress);
        }

        /// <summary>
        /// Gets called when a message is sent.
        /// </summary>
        /// <param name="context">user's connection context</param>
        private void OnSend(UserContext context){}

        /// <summary>
        /// Gets called when the WebSocket Server receives a message.
        /// </summary>
        /// <param name="context">user's connection context</param>
        private void OnReceive(UserContext context)
        {
            Debug.WriteLine("Received Data From: " + context.ClientAddress);
            Debug.WriteLine("Data: " + context.DataFrame.ToString());
        }
    }
}
