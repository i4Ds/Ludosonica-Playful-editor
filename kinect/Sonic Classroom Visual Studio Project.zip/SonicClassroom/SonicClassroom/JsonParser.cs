﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;

namespace SonicClassroom
{
    static class JSONParser
    {
        //standard height of kinect is 1.20 m, 
        private static float _kinectHeight = 1.20f;
        private const String ProgressDiscrete = "discrete";
        private const String NoGesture = "none";
        private const String TrackingLost = "tracking_lost";

        /// <summary>
        /// Contains height of the kinect sensor.
        /// </summary>
        public static float KinectHeight
        {
            get
            {
                return _kinectHeight;
            }

            set
            {
                if (value > 0 && Math.Abs(_kinectHeight - value) > 0.01)
                {
                    _kinectHeight = value;
                }
            }
        }

        /// <summary>
        /// Parse JSON for a continouse gesture
        /// </summary>
        /// <param name="trackingId">TrackingId of the body</param>
        /// <param name="x">x position</param>
        /// <param name="y">y position</param>
        /// <param name="z">z position</param>
        /// <param name="gesture">gesture type</param>
        /// <param name="progress">progress of the gesture</param>
        /// <returns>JSON string</returns>
        public static String ParseContinuousGesture(ulong trackingId, float x, float y, float z, String gesture, float progress)
        {
            return Parse(trackingId, x, y, z, gesture, progress.ToString());
        }

        /// <summary>
        /// Parse JSON for a discrete gesture.
        /// </summary>
        /// <param name="trackingId">TrackingId of the body</param>
        /// <param name="x">x position</param>
        /// <param name="y">y position</param>
        /// <param name="z">z position</param>
        /// <param name="gesture">gesture type</param>
        /// <returns>JSON string</returns>
        public static String ParseDiscreteGesture(ulong trackingId, float x, float y, float z, String gesture)
        {
            return Parse(trackingId, x, y, z, gesture, ProgressDiscrete);
            
        }

        /// <summary>
        /// Parse JSON for a message with a position but without a gesture.
        /// </summary>
        /// <param name="trackingId">TrackingId of the body</param>
        /// <param name="x">x position</param>
        /// <param name="y">y position</param>
        /// <param name="z">z position</param>
        /// <returns>JSON String</returns>
        public static String ParseWithoutGesture(ulong trackingId, float x, float y, float z)
        {
            return Parse(trackingId, x, y, z, NoGesture, ProgressDiscrete);
        }

        /// <summary>
        /// Parse JSON for a tracking lost message.
        /// </summary>
        /// <param name="trackingId">TrackingId</param>
        /// <returns>JSON String</returns>
        public static String ParseTrackingLost(ulong trackingId)
        {
            return Parse(trackingId, 0, 0, 0, TrackingLost, NoGesture);
        }

        /// <summary>
        /// General JSON Parser for all sonic classroom messages.
        /// Adds kinect sensor heigth to y position.
        /// </summary>
        /// <param name="trackingId">TrackingId of the body</param>
        /// <param name="x">x position</param>
        /// <param name="y">y position</param>
        /// <param name="z">z position</param>
        /// <param name="gesture">gesture type</param>
        /// <param name="progress">progress of the gesture</param>
        /// <returns>JSON string</returns>
        private static String Parse(ulong trackingId, float x, float y, float z, String gesture, String progress)
        {
            var json = new StringBuilder();
            
            json.Append("{\"trackingId\":\"");
            json.Append(trackingId);
            json.Append("\",\"x\":\"");
            json.Append(x);
            json.Append("\",\"y\":\"");
            json.Append(y + KinectHeight);
            json.Append("\",\"z\":\"");
            json.Append(z);
            json.Append("\",\"gesture\":\"");
            json.Append(gesture);
            json.Append("\",\"progress\":\"");
            json.Append(progress);
            json.Append("\"}");
            
            return json.ToString();
            
        }
    }
}
